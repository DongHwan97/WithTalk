package com.example.sttexample;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TTSFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TTSFragment extends Fragment implements View.OnClickListener, TextToSpeech.OnInitListener  {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private EditText edit_readText;
    private Button btn_speech;
    private TextToSpeech tts;

    public TTSFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FirstFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TTSFragment newInstance(String param1, String param2) {
        TTSFragment fragment = new TTSFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    // 글자 읽어주기
    private void Speech() {
        String text = edit_readText.getText().toString().trim();
        tts.setPitch((float) 1.0);// 음량 기본값
        tts.setSpeechRate((float) 1.0); // 재생속도 기본값
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {// 작업성공
            int language = tts.setLanguage(Locale.KOREAN);  // 언어 설정
            if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {// 언어 데이터가 없거나, 지원하지 않는경우
                btn_speech.setEnabled(false);
                Toast.makeText(this, "지원하지 않는 언어입니다.", Toast.LENGTH_SHORT).show();
            } else {
                btn_speech.setEnabled(true);// 준비 완료
            }
        } else {
            Toast.makeText(this, "작업에 실패하였습니다.", Toast.LENGTH_SHORT).show();// 작업 실패
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_speech:
                Speech();
                break;
            default:
                break;
        }
    }
    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        edit_readText = (EditText) inflater.findViewById(R.id.edit_readText);
        btn_speech = (Button) rootView.findViewById(R.id.btn_speech);
        btn_speech.setEnabled(false);
        btn_speech.setOnClickListener(this);
        tts = new TextToSpeech(this, this);// 기본생성자
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tts, container, false);
    }
}