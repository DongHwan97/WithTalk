package com.example.sttexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViewById(R.id.loginButton).setOnClickListener(onClickListener);
        findViewById(R.id.moveResetPW).setOnClickListener(onClickListener);
        findViewById(R.id.moveSignUp).setOnClickListener(onClickListener);
        TextView Text1 = findViewById(R.id.moveSignUp);
        TextView Text2 = findViewById(R.id.moveResetPW);
    }
    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.loginButton: moveActivity(MainActivity.class);
                    break;
                case R.id.moveSignUp: moveActivity(SignUpActivity.class);
                    break;
                case R.id.moveResetPW: moveActivity(ResetPWActivity.class);
                    break;
            }
        }
    };
    private void moveActivity(Class c){
        Intent intent = new Intent(this,c);
        startActivity(intent);
    }
}